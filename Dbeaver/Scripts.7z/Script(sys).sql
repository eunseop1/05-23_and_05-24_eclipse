-- http 포트 번호 확인
select dbms_xdb.gethttpport as "HTTP-Port" from dual;

-- 계정 정보 확인
select username,account_status,lock_date from dba_users;

-- 잠긴 HR계정을 풀어보자
--ALTER USER hr account unlock;
ALTER USER hr account unlock;

-- 계정 비밀번호 변경
-- ALTER USER 계정명 IDENTIFIED BY "비밀번호";
ALTER USER hr IDENTIFIED BY "123456";

-- 계정 생성
create user jspuser identified by "123456";

-- 권한 설정
grant connect, resource to jspuser;