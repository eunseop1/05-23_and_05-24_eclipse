-- 테이블 목록 보기
SELECT * FROM tab;

-- || : 문자열 연결 연산자
SELECT 
	e.EMPLOYEE_ID 사번, FIRST_NAME || ' ' || LAST_NAME AS 이름
FROM 
	EMPLOYEES e ;

